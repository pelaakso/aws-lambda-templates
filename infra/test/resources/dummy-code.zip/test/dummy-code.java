// This file does not have actual code, it's used for unit tests.
